<style>
    .odd {
        background-color: #f4f4f4 !important;
    }

    .even {
        background-color: white !important;
    }

    th {
        background-color: white !important;
    }

    td {
        padding: 6px !important;
    }

    tr:hover {
        background-color: #ececec !important;
    }

</style>

<!--The Modal--> 
<div class="modal fade" id="myModal" style="position:absolute;">
    <div class="modal-dialog">
        <div class="modal-content" id="modalContent">

        </div>
    </div>
</div>

<!--Panel-->
<div class="panel panel-primary col-lg-10 pvc-customPanel">
    <!--Panel Title-->
    <div class="panel-heading pvc-panelHeading" >
        Visit History
    </div>    

    <!--Panel Body-->
    <div class="panel-body pvc-panelBody">
        <!--div for scroll-->
        <div class="container-fluid" style="overflow: auto; height: 470px;">
            <!--table-->
            <table id="myTable" class="table table-striped table-bordered table-hover" cellspacing="0" width="100%"> 
                <thead> 
                    <tr> 
                        <th style="display: none;"></th>
                        <th>Date</th> 
                        <th>Location</th>
                        <th>Service By(Dr.)</th> 
                        <th>Client Name</th>
                        <th>Pet Name</th> 
                        <th>Diagnosis</th>

                        <th> </th>
                    </tr>
                </thead> 
                <tbody>

                    <!--Populate the table-->    
                    <?php
                    include_once 'db.inc.php';
                    if ($criteria != '4' || $criteria != '5') {
                        if ($vType == 0 && $vDr == 0) {
                            $condition = ' ';
                        } elseif ($vType == 0 && $vDr != 0) {
                            $condition = ' AND  v.serviceby_servicebyID = "' . $vDr . '"';
                        } elseif ($vType != 0 && $vDr == 0) {
                            $condition = ' AND v.location_locationID = "' . $vType . '"';
                        } elseif ($vType != 0 && $vDr != 0) {
                            $condition = ' AND v.location_locationID = "' . $vType . '" AND v.serviceby_servicebyID = "' . $vDr . '"';
                        }
                    }
                    if ($vID != '') {
                        $sql = "SELECT
                                        c.name AS client_name, p.name AS pet_name, v.visitDate, s.displayName, l.locationName, v.diagnosis, v.visitID
                                    FROM
                                        visit AS v
                                    INNER JOIN pet AS p ON v.pet_petID = p.petID
                                    INNER JOIN client AS c ON p.client_clientID = c.clientID
                                    INNER JOIN serviceby AS s ON v.serviceby_servicebyID = s.servicebyID
                                    INNER JOIN location AS l ON v.location_locationID = l.locationID
                                    WHERE
                                        v.visitID = '" . $vID . "'";

                        $result = $conn->query($sql);
//                            echo $sql;
                    } else if ($criteria == '1') {
                        $sql = "SELECT
                                        c.name AS client_name, p.name AS pet_name, v.visitDate, s.displayName, l.locationName, v.diagnosis, v.visitID
                                    FROM
                                        visit AS v
                                    INNER JOIN pet AS p ON v.pet_petID = p.petID
                                    INNER JOIN client AS c ON p.client_clientID = c.clientID
                                    INNER JOIN serviceby AS s ON v.serviceby_servicebyID = s.serviceByID
                                    INNER JOIN location AS l ON v.location_locationID = l.locationID
                                    WHERE
                                        v.serviceby_servicebyID = '" . $vDr . "' LIMIT " . $vRecCount . "";

                        $result = $conn->query($sql);
//                            echo $sql;
                    } else if ($criteria == '2') {
                        $sql = "SELECT
                                        c.name AS client_name, p.name AS pet_name, v.visitDate, s.displayName, l.locationName, v.diagnosis, v.visitID
                                    FROM
                                        visit AS v
                                    INNER JOIN pet AS p ON v.pet_petID = p.petID
                                    INNER JOIN client AS c ON p.client_clientID = c.clientID
                                    INNER JOIN serviceby AS s ON v.serviceby_servicebyID = s.serviceByID
                                    INNER JOIN location AS l ON v.location_locationID = l.locationID
                                    WHERE
                                         v.visitDate = '" . $vDate . "' $condition   LIMIT 500";

                        $result = $conn->query($sql);
//                        echo $sql;
                    } else if ($criteria == '3') {
                        $sql = "SELECT
                                        c.name AS client_name, p.name AS pet_name, v.visitDate, s.displayName, l.locationName, v.diagnosis, v.visitID
                                    FROM
                                        visit AS v
                                    INNER JOIN pet AS p ON v.pet_petID = p.petID
                                    INNER JOIN client AS c ON p.client_clientID = c.clientID
                                    INNER JOIN serviceby AS s ON v.serviceby_servicebyID = s.serviceByID
                                    INNER JOIN location AS l ON v.location_locationID = l.locationID
                                    WHERE
                                         v.visitDate BETWEEN '" . $vFromDate . "' AND '" . $vToDate . "' $condition   LIMIT 500";

                        $result = $conn->query($sql);
//                        echo $sql;
                    } else if ($criteria == '4') {
                        $sql = "SELECT
                                        c.name AS client_name, p.name AS pet_name, v.visitDate, s.displayName, l.locationName, v.diagnosis, v.visitID
                                    FROM
                                        visit AS v
                                    INNER JOIN pet AS p ON v.pet_petID = p.petID
                                    INNER JOIN client AS c ON p.client_clientID = c.clientID
                                    INNER JOIN serviceby AS s ON v.serviceby_servicebyID = s.serviceByID
                                    INNER JOIN location AS l ON v.location_locationID = l.locationID
                                    WHERE
                                         v.pet_petID = '" . $pID . "' LIMIT 500";

                        $result = $conn->query($sql);
//                        echo $sql;
                    } else if ($criteria == '5') {
                        $sql = "SELECT
                                        c.name AS client_name, p.name AS pet_name, v.visitDate, s.displayName, l.locationName, v.diagnosis, v.visitID
                                    FROM
                                        visit AS v
                                    INNER JOIN pet AS p ON v.pet_petID = p.petID
                                    INNER JOIN client AS c ON p.client_clientID = c.clientID
                                    INNER JOIN serviceby AS s ON v.serviceby_servicebyID = s.serviceByID
                                    INNER JOIN location AS l ON v.location_locationID = l.locationID
                                    WHERE
                                        c.code = '" . $cCode . "'   LIMIT 500";

                        $result = $conn->query($sql);
//                        echo $sql;
                    }
                    while ($row = $result->fetch_assoc()) {
                        echo '<tr>';
//       --------------------- Table Columns ------------------------------
                        echo' <td style="display: none;">' . $row["visitID"] . '</td>';
                        echo'<td>' . date_format(date_create($row["visitDate"]), "d/m/Y");
                        '</td>';
                        echo'<td>' . $row["locationName"] . '</td>';
                        echo'<td>' . $row["displayName"] . '</td>';
                        echo'<td>' . $row["client_name"] . '</td>';
                        echo'<td>' . $row["pet_name"] . '</td>';
                        echo'<td>' . $row["diagnosis"] . '</td>';

                        echo '<td style="white-space: nowrap; text-align: center;">
                                <button onclick="openModalInfo(this);" type="button" class="btn btn-primary btn-xs">Info</button>
                                <button onclick="openModalEdit(this);" type="button" class="btn btn-warning btn-xs ';
                        echo isset($_SESSION['pvc_mod_client']) && ($_SESSION['pvc_mod_client'] > 3) ? '' : 'display-none';
                        echo '">Edit</button>
                                </td>';
                        echo '</tr>';
                    }
                    $conn->close();
                    ?>    
                </tbody> 
            </table>
        </div>
    </div>
</div>

<script>
//    JS for data table functionality
    $(document).ready(function () {
        $('#myTable').DataTable();

    });


    function openModalInfo(value) {
        var visitID = $(value).parent().parent().find('td').eq(0).text();
//        alert(visitID);
        $("#imgLoading").show();
        $.ajax({
            type: 'POST',
            data: {
                task: 'visit_visitInfo',
                vID: visitID
            },
            url: 'ajax.php',
            async: true,
            success: function (data) {
                $("#imgLoading").hide();
                $("#modalContent").html(data);
            },
            complete: function () {
                //$("#myModal").modal({backdrop: 'static', keyboard: false});
                $("#myModal").modal("show");
                $(".pvc-centreContent").addClass("after_modal_appended");

                //appending modal background inside the blue div
                $('.modal-backdrop').appendTo('.pvc-centreContent');

                //remove the padding right and modal-open class from the body tag which bootstrap adds when a modal is shown
                $('body').removeClass("modal-open");
                $('body').css("padding-right", "");
            }
        });
    }

    function openModalEdit(value) {
        var visitID = $(value).parent().parent().find('td').eq(0).text();
        $("#imgLoading").show();
//        alert(visitID);
        $.ajax({
            type: 'POST',
            data: {
                task: 'visit_visitEdit',
                vID: visitID
            },
            url: 'ajax.php',
            async: true,
            success: function (data) {
                $("#imgLoading").hide();
                $("#modalContent").html(data);
            },
            complete: function () {
                //$("#myModal").modal({backdrop: 'static', keyboard: false});
                $("#myModal").modal("show");
                //document.write(x);
                $(".pvc-centreContent").addClass("after_modal_appended");

                //appending modal background inside the blue div
                $('.modal-backdrop').appendTo('.pvc-centreContent');

                //remove the padding right and modal-open class from the body tag which bootstrap adds when a modal is shown
                $('body').removeClass("modal-open");
                $('body').css("padding-right", "");
            }
        });
    }
</script>
