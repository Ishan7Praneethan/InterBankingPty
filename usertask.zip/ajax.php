<?php

/*
 * All Rights Reserved
 * (c) Priyanga Senanayaka 
 * 2018
 */

session_start();
//require_once 'includes/db.inc.php'; //to connect with the data base

date_default_timezone_set('Asia/Colombo');

// receiving the values send from ajax callback functions
//$task = (filter_input(INPUT_GET, 'task')) ? trim(filter_input(INPUT_GET, 'task')) : '';

$task = (filter_input(INPUT_POST, 'task')) ? trim(filter_input(INPUT_POST, 'task')) : '';

$criteria = (filter_input(INPUT_POST, 'criteria')) ? trim(filter_input(INPUT_POST, 'criteria')) : '';

$cCode = (filter_input(INPUT_POST, 'cCode')) ? trim(filter_input(INPUT_POST, 'cCode')) : '';
$cTitle = (filter_input(INPUT_POST, 'cTitle')) ? trim(filter_input(INPUT_POST, 'cTitle')) : '';
$cName = (filter_input(INPUT_POST, 'cName')) ? trim(filter_input(INPUT_POST, 'cName')) : '';
$cAddress = (filter_input(INPUT_POST, 'cAddress')) ? trim(filter_input(INPUT_POST, 'cAddress')) : '';
$cTel = (filter_input(INPUT_POST, 'cTel')) ? trim(filter_input(INPUT_POST, 'cTel')) : '';
$cEmail = (filter_input(INPUT_POST, 'cEmail')) ? trim(filter_input(INPUT_POST, 'cEmail')) : '';
$cRegDate = (filter_input(INPUT_POST, 'cRegDate')) ? trim(filter_input(INPUT_POST, 'cRegDate')) : '';
$cComment = (filter_input(INPUT_POST, 'cComment')) ? trim(filter_input(INPUT_POST, 'cComment')) : '';
$cID = (filter_input(INPUT_POST, 'cID')) ? trim(filter_input(INPUT_POST, 'cID')) : '';

$invoiceid = (filter_input(INPUT_POST, 'invoiceid')) ? trim(filter_input(INPUT_POST, 'invoiceid')) : '';
$field = (filter_input(INPUT_POST, 'field')) ? trim(filter_input(INPUT_POST, 'field')) : '';
$text = (filter_input(INPUT_POST, 'text')) ? trim(filter_input(INPUT_POST, 'text')) : '';

$pName = (filter_input(INPUT_POST, 'pName')) ? trim(filter_input(INPUT_POST, 'pName')) : '';
$pBreed = (filter_input(INPUT_POST, 'pBreed')) ? trim(filter_input(INPUT_POST, 'pBreed')) : '';
$pSpecies = (filter_input(INPUT_POST, 'pSpecies')) ? trim(filter_input(INPUT_POST, 'pSpecies')) : '';
$pGender = (filter_input(INPUT_POST, 'pGender')) ? trim(filter_input(INPUT_POST, 'pGender')) : '';
$pDOB = (filter_input(INPUT_POST, 'pDOB')) ? trim(filter_input(INPUT_POST, 'pDOB')) : '';
if (isset($pDOB) AND $pDOB != '') {
    $pDOB_mod = '"' . $pDOB . '"';
} else {
    $pDOB_mod = 'NULL';
}
$pMicrochipNo = (filter_input(INPUT_POST, 'pMicrochipNo')) ? trim(filter_input(INPUT_POST, 'pMicrochipNo')) : '';
$pComment = (filter_input(INPUT_POST, 'pComment')) ? trim(filter_input(INPUT_POST, 'pComment')) : '';
$pCode = (filter_input(INPUT_POST, 'pCode')) ? trim(filter_input(INPUT_POST, 'pCode')) : '';
$pID = (filter_input(INPUT_POST, 'pID')) ? trim(filter_input(INPUT_POST, 'pID')) : '';
$prevOwner = (filter_input(INPUT_POST, 'prevOwner')) ? trim(filter_input(INPUT_POST, 'prevOwner')) : '';

$vID = (filter_input(INPUT_POST, 'vID')) ? trim(filter_input(INPUT_POST, 'vID')) : '';
$vDate = (filter_input(INPUT_POST, 'vDate')) ? trim(filter_input(INPUT_POST, 'vDate')) : '';
$vDr = (filter_input(INPUT_POST, 'vDr')) ? trim(filter_input(INPUT_POST, 'vDr')) : '';
$vType = (filter_input(INPUT_POST, 'vType')) ? trim(filter_input(INPUT_POST, 'vType')) : '';
$vComplaint = (filter_input(INPUT_POST, 'vComplaint')) ? trim(filter_input(INPUT_POST, 'vComplaint')) : '';
$vObservation = (filter_input(INPUT_POST, 'vObservation')) ? trim(filter_input(INPUT_POST, 'vObservation')) : '';
$vInvestigation = (filter_input(INPUT_POST, 'vInvestigation')) ? trim(filter_input(INPUT_POST, 'vInvestigation')) : '';
$vDiagnosis = (filter_input(INPUT_POST, 'vDiagnosis')) ? trim(filter_input(INPUT_POST, 'vDiagnosis')) : '';
$vManagement = (filter_input(INPUT_POST, 'vManagement')) ? trim(filter_input(INPUT_POST, 'vManagement')) : '';
$vRemarks = (filter_input(INPUT_POST, 'vRemarks')) ? trim(filter_input(INPUT_POST, 'vRemarks')) : '';
$vFromDate = (filter_input(INPUT_POST, 'vFromDate')) ? trim(filter_input(INPUT_POST, 'vFromDate')) : '';
$vToDate = (filter_input(INPUT_POST, 'vToDate')) ? trim(filter_input(INPUT_POST, 'vToDate')) : '';
$vRecCount = (filter_input(INPUT_POST, 'vRecCount')) ? trim(filter_input(INPUT_POST, 'vRecCount')) : '';

$billDate = (filter_input(INPUT_POST, 'billDate')) ? trim(filter_input(INPUT_POST, 'billDate')) : '';
$billFromDate = (filter_input(INPUT_POST, 'billFromDate')) ? trim(filter_input(INPUT_POST, 'billFromDate')) : '';
$billToDate = (filter_input(INPUT_POST, 'billToDate')) ? trim(filter_input(INPUT_POST, 'billToDate')) : '';
$billType = (filter_input(INPUT_POST, 'billType')) ? trim(filter_input(INPUT_POST, 'billType')) : '';
$billLocation = (filter_input(INPUT_POST, 'billLocation')) ? trim(filter_input(INPUT_POST, 'billLocation')) : '';
$billStatus = (filter_input(INPUT_POST, 'billStatus')) ? trim(filter_input(INPUT_POST, 'billStatus')) : '';



$itemCode = (filter_input(INPUT_POST, 'itemCode')) ? trim(filter_input(INPUT_POST, 'itemCode')) : '';
$itemName = (filter_input(INPUT_POST, 'itemName')) ? trim(filter_input(INPUT_POST, 'itemName')) : '';
$itemID = (filter_input(INPUT_POST, 'itemID')) ? trim(filter_input(INPUT_POST, 'itemID')) : '';
$unit = (filter_input(INPUT_POST, 'unit')) ? trim(filter_input(INPUT_POST, 'unit')) : '';
$unitPrice = (filter_input(INPUT_POST, 'unitPrice')) ? trim(filter_input(INPUT_POST, 'unitPrice')) : '';
$itemCategory = (filter_input(INPUT_POST, 'itemCategory')) ? trim(filter_input(INPUT_POST, 'itemCategory')) : '';
$priceEdit = (filter_input(INPUT_POST, 'priceEdit')) ? trim(filter_input(INPUT_POST, 'priceEdit')) : '';
$itemComment = (filter_input(INPUT_POST, 'itemComment')) ? trim(filter_input(INPUT_POST, 'itemComment')) : '';


$editedPrice = (filter_input(INPUT_POST, 'editedPrice')) ? trim(filter_input(INPUT_POST, 'editedPrice')) : '';
$qty = (filter_input(INPUT_POST, 'qty')) ? trim(filter_input(INPUT_POST, 'qty')) : '';
$total = (filter_input(INPUT_POST, 'total')) ? trim(filter_input(INPUT_POST, 'total')) : '';
$discount = (filter_input(INPUT_POST, 'discount')) ? trim(filter_input(INPUT_POST, 'discount')) : '';
$invoiceID = (filter_input(INPUT_POST, 'invoiceID')) ? trim(filter_input(INPUT_POST, 'invoiceID')) : '';
$invoiceItemID = (filter_input(INPUT_POST, 'invoiceItemID')) ? trim(filter_input(INPUT_POST, 'invoiceItemID')) : '';
$cashPmnt = (filter_input(INPUT_POST, 'cashPmnt')) ? trim(filter_input(INPUT_POST, 'cashPmnt')) : 0;
$advPmnt = (filter_input(INPUT_POST, 'advPmnt')) ? trim(filter_input(INPUT_POST, 'advPmnt')) : 0;
$ccPmnt = (filter_input(INPUT_POST, 'ccPmnt')) ? trim(filter_input(INPUT_POST, 'ccPmnt')) : 0;
$chPmnt = (filter_input(INPUT_POST, 'chPmnt')) ? trim(filter_input(INPUT_POST, 'chPmnt')) : 0;
$ccNo = (filter_input(INPUT_POST, 'ccNo')) ? trim(filter_input(INPUT_POST, 'ccNo')) : '';
$chNo = (filter_input(INPUT_POST, 'chNo')) ? trim(filter_input(INPUT_POST, 'chNo')) : '';
$billTotal = (filter_input(INPUT_POST, 'billTotal')) ? trim(filter_input(INPUT_POST, 'billTotal')) : 0;
$billBalance = (filter_input(INPUT_POST, 'billBalance')) ? trim(filter_input(INPUT_POST, 'billBalance')) : 0;
$billRemarks = (filter_input(INPUT_POST, 'billRemarks')) ? trim(filter_input(INPUT_POST, 'billRemarks')) : '';

$supplierID = (filter_input(INPUT_POST, 'supplier')) ? trim(filter_input(INPUT_POST, 'supplier')) : '';
$batchNo = (filter_input(INPUT_POST, 'batchNo')) ? trim(filter_input(INPUT_POST, 'batchNo')) : '';
$expDate = (filter_input(INPUT_POST, 'expDate')) ? trim(filter_input(INPUT_POST, 'expDate')) : '';
$locationID = (filter_input(INPUT_POST, 'locationID')) ? trim(filter_input(INPUT_POST, 'locationID')) : '';
$locationID_from = (filter_input(INPUT_POST, 'locationID_from')) ? trim(filter_input(INPUT_POST, 'locationID_from')) : '';
$locationID_to = (filter_input(INPUT_POST, 'locationID_to')) ? trim(filter_input(INPUT_POST, 'locationID_to')) : '';

$itemBalance = (filter_input(INPUT_POST, 'itemBalance')) ? trim(filter_input(INPUT_POST, 'itemBalance')) : '';
$actualBalance = (filter_input(INPUT_POST, 'actualBalance')) ? trim(filter_input(INPUT_POST, 'actualBalance')) : '';
$comment = (filter_input(INPUT_POST, 'comment')) ? trim(filter_input(INPUT_POST, 'comment')) : '';

$title = (filter_input(INPUT_POST, 'title')) ? trim(filter_input(INPUT_POST, 'title')) : '';
$lastName = (filter_input(INPUT_POST, 'lastName')) ? trim(filter_input(INPUT_POST, 'lastName')) : '';
$otherNames = (filter_input(INPUT_POST, 'otherNames')) ? trim(filter_input(INPUT_POST, 'otherNames')) : '';
$displayName = (filter_input(INPUT_POST, 'displayName')) ? trim(filter_input(INPUT_POST, 'displayName')) : '';
$tel = (filter_input(INPUT_POST, 'tel')) ? trim(filter_input(INPUT_POST, 'tel')) : '';
$email = (filter_input(INPUT_POST, 'email')) ? trim(filter_input(INPUT_POST, 'email')) : '';
$un = (filter_input(INPUT_POST, 'un')) ? trim(filter_input(INPUT_POST, 'un')) : '';
$pw = (filter_input(INPUT_POST, 'pw')) ? trim(filter_input(INPUT_POST, 'pw')) : '';
$status = (filter_input(INPUT_POST, 'status')) ? trim(filter_input(INPUT_POST, 'status')) : '';

//for pw update
$pw_old = (filter_input(INPUT_POST, 'pw_old')) ? trim(filter_input(INPUT_POST, 'pw_old')) : '';
$pw_new1 = (filter_input(INPUT_POST, 'pw_new1')) ? trim(filter_input(INPUT_POST, 'pw_new1')) : '';
$pw_new2 = (filter_input(INPUT_POST, 'pw_new2')) ? trim(filter_input(INPUT_POST, 'pw_new2')) : '';

//for User management
$uID = (filter_input(INPUT_POST, 'uID')) ? trim(filter_input(INPUT_POST, 'uID')) : '';
$active = (filter_input(INPUT_POST, 'active')) ? trim(filter_input(INPUT_POST, 'active')) : '';
$client = (filter_input(INPUT_POST, 'client')) ? trim(filter_input(INPUT_POST, 'client')) : '';
$pet = (filter_input(INPUT_POST, 'pet')) ? trim(filter_input(INPUT_POST, 'pet')) : '';
$visit = (filter_input(INPUT_POST, 'visit')) ? trim(filter_input(INPUT_POST, 'visit')) : '';
$bill = (filter_input(INPUT_POST, 'bill')) ? trim(filter_input(INPUT_POST, 'bill')) : '';
$item = (filter_input(INPUT_POST, 'item')) ? trim(filter_input(INPUT_POST, 'item')) : '';
$stock = (filter_input(INPUT_POST, 'stock')) ? trim(filter_input(INPUT_POST, 'stock')) : '';
$profile = (filter_input(INPUT_POST, 'profile')) ? trim(filter_input(INPUT_POST, 'profile')) : '';
$admin = (filter_input(INPUT_POST, 'admin')) ? trim(filter_input(INPUT_POST, 'admin')) : '';
$pharmacy = (filter_input(INPUT_POST, 'pharmacy')) ? trim(filter_input(INPUT_POST, 'pharmacy')) : '';
$lab = (filter_input(INPUT_POST, 'lab')) ? trim(filter_input(INPUT_POST, 'lab')) : '';
$investigation = (filter_input(INPUT_POST, 'investigation')) ? trim(filter_input(INPUT_POST, 'investigation')) : '';
$report = (filter_input(INPUT_POST, 'report')) ? trim(filter_input(INPUT_POST, 'report')) : '';
$investigationID = (filter_input(INPUT_POST, 'investigationid')) ? trim(filter_input(INPUT_POST, 'investigationid')) : '';
$categoryID = (filter_input(INPUT_POST, 'categoryID')) ? trim(filter_input(INPUT_POST, 'categoryID')) : '';

$supplierName = (filter_input(INPUT_POST, 'supplierName')) ? trim(filter_input(INPUT_POST, 'supplierName')) : '';

$fullName_ServiceTeam = (filter_input(INPUT_POST, 'fullName_ServiceTeam')) ? trim(filter_input(INPUT_POST, 'fullName_ServiceTeam')) : '';
$displayName_ServiceTeam = (filter_input(INPUT_POST, 'displayName_ServiceTeam')) ? trim(filter_input(INPUT_POST, 'displayName_ServiceTeam')) : '';
$designation_ServiceTeam = (filter_input(INPUT_POST, 'designation_ServiceTeam')) ? trim(filter_input(INPUT_POST, 'designation_ServiceTeam')) : '';
$empNo_ServiceTeam = (filter_input(INPUT_POST, 'empNo_ServiceTeam')) ? trim(filter_input(INPUT_POST, 'empNo_ServiceTeam')) : '';
$category_ServiceTeam = (filter_input(INPUT_POST, 'category_ServiceTeam')) ? trim(filter_input(INPUT_POST, 'category_ServiceTeam')) : '';
$tel_ServiceTeam = (filter_input(INPUT_POST, 'tel_ServiceTeam')) ? trim(filter_input(INPUT_POST, 'tel_ServiceTeam')) : '';


$sc1 = (filter_input(INPUT_POST, 'sc1')) ? trim(filter_input(INPUT_POST, 'sc1')) : '';
$sc2 = (filter_input(INPUT_POST, 'sc2')) ? trim(filter_input(INPUT_POST, 'sc2')) : '';
$sc3 = (filter_input(INPUT_POST, 'sc3')) ? trim(filter_input(INPUT_POST, 'sc3')) : '';
$sc4 = (filter_input(INPUT_POST, 'sc4')) ? trim(filter_input(INPUT_POST, 'sc4')) : '';
$sc5 = (filter_input(INPUT_POST, 'sc5')) ? trim(filter_input(INPUT_POST, 'sc5')) : '';

$date = (filter_input(INPUT_POST, 'date')) ? trim(filter_input(INPUT_POST, 'date')) : '';
$location = (filter_input(INPUT_POST, 'location')) ? trim(filter_input(INPUT_POST, 'location')) : '';

$componentName = (filter_input(INPUT_POST, 'componentName')) ? trim(filter_input(INPUT_POST, 'componentName')) : '';
$componentID = (filter_input(INPUT_POST, 'componentID')) ? trim(filter_input(INPUT_POST, 'componentID')) : '';
$componentUnit = (filter_input(INPUT_POST, 'componentUnit')) ? trim(filter_input(INPUT_POST, 'componentUnit')) : '';
$componentRefRange = (filter_input(INPUT_POST, 'componentRefRange')) ? trim(filter_input(INPUT_POST, 'componentRefRange')) : '';
$componentSize = (filter_input(INPUT_POST, 'componentSize')) ? trim(filter_input(INPUT_POST, 'componentSize')) : '';
$componentOrder = (filter_input(INPUT_POST, 'componentOrder')) ? trim(filter_input(INPUT_POST, 'componentOrder')) : '';

$ixorderID = (filter_input(INPUT_POST, 'ixorderID')) ? trim(filter_input(INPUT_POST, 'ixorderID')) : '';

$input1 = (filter_input(INPUT_POST, 'input1')) ? trim(filter_input(INPUT_POST, 'input1')) : '';
$input2 = (filter_input(INPUT_POST, 'input2')) ? trim(filter_input(INPUT_POST, 'input2')) : '';
$input3 = (filter_input(INPUT_POST, 'input3')) ? trim(filter_input(INPUT_POST, 'input3')) : '';
$input4 = (filter_input(INPUT_POST, 'input4')) ? trim(filter_input(INPUT_POST, 'input4')) : '';
$input5 = (filter_input(INPUT_POST, 'input5')) ? trim(filter_input(INPUT_POST, 'input5')) : '';
$input6 = (filter_input(INPUT_POST, 'input6')) ? trim(filter_input(INPUT_POST, 'input6')) : '';
$input7 = (filter_input(INPUT_POST, 'input1')) ? trim(filter_input(INPUT_POST, 'input7')) : '';
$input8 = (filter_input(INPUT_POST, 'input8')) ? trim(filter_input(INPUT_POST, 'input8')) : '';
$input9 = (filter_input(INPUT_POST, 'input9')) ? trim(filter_input(INPUT_POST, 'input9')) : '';
$input10 = (filter_input(INPUT_POST, 'input10')) ? trim(filter_input(INPUT_POST, 'input10')) : '';
$input11 = (filter_input(INPUT_POST, 'input11')) ? trim(filter_input(INPUT_POST, 'input11')) : '';
$input12 = (filter_input(INPUT_POST, 'input12')) ? trim(filter_input(INPUT_POST, 'input12')) : '';
$input13 = (filter_input(INPUT_POST, 'input13')) ? trim(filter_input(INPUT_POST, 'input13')) : '';
$input14 = (filter_input(INPUT_POST, 'input14')) ? trim(filter_input(INPUT_POST, 'input14')) : '';
$input15 = (filter_input(INPUT_POST, 'input15')) ? trim(filter_input(INPUT_POST, 'input15')) : '';
$input16 = (filter_input(INPUT_POST, 'input16')) ? trim(filter_input(INPUT_POST, 'input16')) : '';
$input17 = (filter_input(INPUT_POST, 'input17')) ? trim(filter_input(INPUT_POST, 'input17')) : '';
$input18 = (filter_input(INPUT_POST, 'input18')) ? trim(filter_input(INPUT_POST, 'input18')) : '';
$input19 = (filter_input(INPUT_POST, 'input19')) ? trim(filter_input(INPUT_POST, 'input19')) : '';

$field1 = (filter_input(INPUT_POST, 'field1')) ? trim(filter_input(INPUT_POST, 'field1')) : '';
$field2 = (filter_input(INPUT_POST, 'field2')) ? trim(filter_input(INPUT_POST, 'field2')) : '';
$field3 = (filter_input(INPUT_POST, 'field3')) ? trim(filter_input(INPUT_POST, 'field3')) : '';
$field4 = (filter_input(INPUT_POST, 'field4')) ? trim(filter_input(INPUT_POST, 'field4')) : '';
$field5 = (filter_input(INPUT_POST, 'field5')) ? trim(filter_input(INPUT_POST, 'field5')) : '';
$field6 = (filter_input(INPUT_POST, 'field6')) ? trim(filter_input(INPUT_POST, 'field6')) : '';
$field7 = (filter_input(INPUT_POST, 'field7')) ? trim(filter_input(INPUT_POST, 'field7')) : '';
$field8 = (filter_input(INPUT_POST, 'field8')) ? trim(filter_input(INPUT_POST, 'field8')) : '';
$field9 = (filter_input(INPUT_POST, 'field9')) ? trim(filter_input(INPUT_POST, 'field9')) : '';
$field10 = (filter_input(INPUT_POST, 'field10')) ? trim(filter_input(INPUT_POST, 'field10')) : '';
$field11 = (filter_input(INPUT_POST, 'field11')) ? trim(filter_input(INPUT_POST, 'field11')) : '';
$field12 = (filter_input(INPUT_POST, 'field12')) ? trim(filter_input(INPUT_POST, 'field12')) : '';
$field13 = (filter_input(INPUT_POST, 'field13')) ? trim(filter_input(INPUT_POST, 'field13')) : '';
$field14 = (filter_input(INPUT_POST, 'field14')) ? trim(filter_input(INPUT_POST, 'field14')) : '';
$field15 = (filter_input(INPUT_POST, 'field15')) ? trim(filter_input(INPUT_POST, 'field15')) : '';
$field16 = (filter_input(INPUT_POST, 'field16')) ? trim(filter_input(INPUT_POST, 'field16')) : '';
$field17 = (filter_input(INPUT_POST, 'field17')) ? trim(filter_input(INPUT_POST, 'field17')) : '';
$field18 = (filter_input(INPUT_POST, 'field18')) ? trim(filter_input(INPUT_POST, 'field18')) : '';
$field19 = (filter_input(INPUT_POST, 'field19')) ? trim(filter_input(INPUT_POST, 'field19')) : '';

$recordCount = (filter_input(INPUT_POST, 'recordCount')) ? trim(filter_input(INPUT_POST, 'recordCount')) : '';





$file = (filter_input(INPUT_POST, 'file')) ? trim(filter_input(INPUT_POST, 'file')) : '';




$testData = (filter_input(INPUT_POST, 'testData')) ? trim(filter_input(INPUT_POST, 'testData')) : '';








//echo 'in ajax';
//echo 'alert ("in ajax")';
//echo $task;


switch ($task) {
    case 'uploadphoto':
        include 't_savefile.php';
        break;

    case 'showNoticeBoard':
        include 'notice.inc.php';
        break;

    case 'showAddClient':
        include 'addClient.inc.php';
        break;

    case 'showListClient':
        include 'clientTable.inc.php';
        //include 'test_model.php';
        break;

    case 'showSearchClient':
        include 'searchClient.inc.php';
        break;

    case 'addClient':
        include 'clientAdded.inc.php';
        break;

    case 'searchClient':
        include 'clientTable.inc.php';
        break;

    case 'showEditedClient':
        include 'clientTable.inc.php';
        break;

    case 'showModalInfo':
        include 'clientInfo.inc.php';
        break;

    case 'showModalEdit':
        include 'clientEdit.inc.php';
        break;

    case 'editClient':
        include 'clientEdited.inc.php';
        //echo 'to edit';
        break;

    case 'showClientDashboard':
        //echo 'dash board';
        include 'clientDashboard_checkID.inc.php';
        break;

    case 'selectClient_forDashboard':
        //echo 'selectClient_forDashboard';
        include 'selectClient_result.inc.php';
        break;
    
     case 'cdb_showModalAdvanceBill':
        //echo 'selectClient_forDashboard';
        include 'bill_createVariablesForAdvanceInvoice.php';
        break;
    
//    case 'bill_openCreditBillForEdit':
//        //echo 'selectClient_forDashboard';
//        include 'bill_createVariablesForAdvanceInvoice.php';
//        break;
    
    
    
    

    case 'showAddPet':
        //echo $cID;
        include 'pet_checkClientID_forAddPet.php';
        break;

    case 'selectClient_forAddPet':
        //echo 'inajax;';
        include 'pet_clientResult_forAddPet.php';
        break;

    case 'savePet':
        //echo 'in ajax;';
        include 'pet_add_action.php';
        break;

    case 'showPetDashboard':
        //echo 'dash board';
        include 'pet_dashboard_checkID.inc.php';
        break;

    case 'selectPet_forDashboard':
        //echo 'dash board';
        include 'pet_result_forDashboard.php';
        break;

    case 'showPetTransfer':
        //echo 'dash board';
        include 'pet_transfer_checkID.inc.php';
        break;

    case 'selectPet_forTransfer':
        include 'pet_result_forTransfer.php';
        break;

    case 'petSelectForTransfer_transfer':
        include 'pet_transfer.php';
        break;

    case 'petTransfer_changePet':
        include 'pet_select_forTransfer.php';
        break;

    case 'selectClient_petTransfer_cCode':
        include 'pet_select_client_forTransfer.php';
        break;

    case 'petTransfer_transfer':
        //echo $cID.'dash board pet_transfer_done.php'.$pID;
        include 'pet_transfer_done.php';
        break;

    case 'index_searchPet':
        //echo $cID.'dash board pet_transfer_done.php'.$pID;
        include 'pet_search.php';
        break;

    case 'petSearch_search':
        //echo 'pet_searchResultTable.php';
        include 'pet_searchResultTable.php';
        break;

    case 'petSearchResult_showModalInfo':
        //echo 'pet_searchResultTable.php';
        include 'pet_infoForModal.php';
        break;

    case 'petSearchResult_showModalEdit':
        //echo 'pet_searchResultTable.php';
        include 'pet_editForModal.php';
        break;

    case 'editPet_save':
        //echo 'ajax';
        include 'pet_edited.php';
        break;


//  ---------------------------------------------- // 
    case 'index_listPet':
        include 'pet_petTable.inc.php';
        break;

    case 'showEditedPet':
        //echo 'ajax';
        include 'pet_petTable.inc.php';
        break;

    case 'selectPetForEdit':
        //echo 'inajax;';
        include 'pet_selectPetForEdit.inc.php';
        break;

    case 'selectedPetForEdit':
        //echo 'inajax;';
        include 'pet_selectedPetForEdit.inc.php';
        break;

    case 'selectClientForEdit':
//        echo 'in ajax';
        include 'selectClientForEdit.inc.php';
        break;


    case 'selectedClient_forEdit':
//        echo 'in ajax';
        include 'selectedClient_forEdit.inc.php';
        break;

//-------------------------------------------------------------------

    /*     * ************* */
    /* Visit MOdule */
    /*     * ************* */

    case 'showAddVisit':
        //echo 'in ajax';
        include 'visit_add_checkPetID.inc.php';
        break;

    case 'selectPet_forAddVisit':
        //echo 'in ajax';
        include 'visit_pet_result_forAddVisit.php';
        break;

    case 'saveVisit':
        //echo 'in ajax';
        include 'visit_add_action.php';
        break;

    case 'showModalVisitInfo':
        //echo $vID;
        include 'visit_modalVisitInfo.php';
        break;

    case 'showViewVisit':
        //echo "in ajax";
        include 'visit_viewVisit_criteria.php';
        break;

    case 'loadViewCriteria':
        //echo "in ajax";
        include 'visit_loadViewCriteria.php';
        break;


//-------------------------------------------------------------------   

    case 'selectedPetForView':
        //echo "in ajax";
        include 'visit-viewCriteria_selectedPet.php';
        break;

    case 'selectedClientForView':
        //echo "in ajax";
        include 'visit-viewCriteria_selectedClient.php';
        break;

    case 'viewVisit':
        //echo "in ajax";
        include 'visit_table.php';
        break;

    case 'visit_visitInfo':
//        echo "in ajax";
        include 'visit_info.php';
        break;

    case 'visit_visitEdit':
//        echo "in ajax";
        include 'visit_visitEdit.php';
        break;

    case 'saveEditVisit':
//        echo $vRemarks;;
        include 'visit_edit_action.php';
        break;

    /*     * ************* */
    /* Bill MOdule */
    /*     * ************* */

    case 'openClinicBillPendingList':
        include 'bill_clinicBill_pendingList.php';
        break;

    case 'addClinicInvoice':
        //echo $vID;
        include 'bill_invoice.php';
        break;

    case 'openClinicInvoice':
        //echo $vID;
        include 'bill_invoice.php';
        break;

    case 'showItemByCode':
        //echo $vID;
        include 'bill_showItemByCode.php';
        break;
    
    case 'loadItemByCode_withBalance':
        //echo $vID;
        include 'bill_showItemByCode.php';
        break;
    
    case 'loadItemByCode_withBalanceTable':
        //echo $vID;
        include 'bill_showItemByCode.php';
        break;
    
    case 'loadItemByCode_withBalanceTableFull':
        //echo $vID;
        include 'bill_showItemByCode.php';
        break;
    
    case 'loadItemByCode_withBalanceInLocation':
        //echo $vID;
        include 'bill_showItemByCode.php';
        break;
    
    case 'loadItemByName_withBalanceInLocation':
        //echo $vID;
        include 'bill_showItemByCode.php';
        break;
    
     case 'loadItemByName_withBalanceTable':
        //echo $vID;
        include 'bill_showItemByCode.php';
        break;
    
    case 'loadItemByName_withBalanceTableFull':
        //echo $vID;
        include 'bill_showItemByCode.php';
        break;

    case 'loadItemByName':
        //echo $vID;
        include 'bill_showItemByCode.php';
        break;
    
    case 'loadItemByName_withBalance':
        //echo $vID;
        include 'bill_showItemByCode.php';
        break;


    case 'openCreditBillList':
        //echo $task;
        include 'bill_openCreditBillList.php';
        break;

    case 'openClinicBillTable':
        //echo $task;
        include 'bill_openClinicBillTable.php';
        break;

    case 'viewClinicBill':
        //      echo "in ajax";
        include 'bill_clinicBillTable.php';
        break;
    
    case 'bill_invoiceInfo':
        //echo $invoiceID;
        include 'bill_viewInvoice.php';
        break;
    
    
    case 'openInvoicePrintView':
        //echo $invoiceID;
        include 'bill_invoicePrintPreview.php';
        break;




    case 'openCreditInvoice':
        //echo $task;
        include 'bill_openCreditInvoice.php';
        break;

    case 'creditBill_showModalInfo':
        //echo $task;
        include 'bill_viewInvoice.php';
        break;

    case 'creditBill_openCreditBill':
        //echo $task;
        include 'bill_invoice.php';
        break;

//    case 'checkClientForAdvanceBill':
//        //echo "in ajax";
//        include 'bill_checkClientForAdvanceBill.php';
//        break;

    case 'showAdvanceBill':
        // echo $cID;
        include 'bill_checkClientForAdvanceBill.php';
        break;

    case 'selectClientForOpenAdvanceBill':
        //echo "in ajax";
        include 'bill_selectClient_forAdvanceBill.php';
        break;

    case 'selectClient_forAdvanceBill':
//        echo $vRemarks;;
        include 'bill_clientResult_forAdvanceBill.php';
        break;

    case 'advanceBill_saveAndPrint':
//        echo $vRemarks;;
        include 'bill_advanceBillSaveAndPrint.php';
        break;


    case 'listAdvanceBill':
//        echo $vRemarks;;
        include 'bill_viewAdvanceBill_criteria.php';
        break;

    case 'loadAdvanceBillCriteria':
//        echo $vRemarks;;
        include 'bill_loadAdvanceBillCriteria.php';
        break;

    case 'viewAdvanceBill':
//        echo $vRemarks;;
        include 'bill_advanceBillTable.php';
        break;


    case 'addInvoiceItem':
        //echo "in ajax";
        include 'bill_addInvoiceItem.php';
        break;

    case 'removeInvoiceItem':
        //echo "in ajax";
        include 'bill_addInvoiceItem.php';
        break;

    case 'saveInvoice':
        //echo "in ajax";
        include 'bill_saveInvoice.php';
        break;

    case 'printInvoice':
        //echo "in ajax";
        include 'bill_printInvoice.php';
        break;
    
    case 'printInvoiceSummary':
        //echo "in ajax";
        include 'bill_printInvoiceSymmary.php';
        break;

    case 'showModalAdvance':
        //echo "in ajax";
        include 'bill_showModalAdvance.php';
        break;
    
    case 'bill_advanceBillInfo':
        //       echo "in ajax";
        include 'bill_createVariablesForAdvanceInvoice.php';
        break;




    /*     * ************* */
    /* Item Module */
    /*     * ************* */

    case 'addBillingItem':
        //echo "in ajax";
        include 'item_addBillingItem.php';
        break;

    case 'listEditItem':
        //echo "in ajax";
        include 'item_listEditItem.php';
        break;

    case 'saveBillingItem':
        //echo "in ajax";
        include 'item_saveBillingItem.php';
        break;
    
    case 'loadListItemCriteria':
        //echo $invoiceID;
        include 'item_listItemLoadCategory.php';
        break;

    case 'viewListItems':
        //echo $invoiceID;
        include 'item_listEditItemTable.php';
        break;
    
    case 'item_info':
        //echo 'call';
        include 'item_info.php';
        break;
    
    

    /*     * ************* */
    /* Stock Module */
    /*     * ************* */

    case 'stockReceiving':
        //echo "in ajax";
        include 'stock_stockReceiving.php';
        break;
    
    case 'stock_reveive_save':
        //echo "in ajax";
        include 'stock_saveStockReceiving.php';
        break;
    
    case 'stockDistribution':
        //echo "in ajax";
        include 'stock_stockDistribution.php';
        break;
    
    case 'stock_distribute_save':
        //echo "in ajax";
        include 'stock_stockDistributionSave.php';
        break;
    
    case 'stockTransfer':
        //echo "in ajax";
        include 'stock_stockTransfer.php';
        break;
    
    case 'stock_tranfer_save':
        //echo "in ajax";
        include 'stock_stockTransferSave.php';
        break;
    
    
    
    case 'stockVerification':
        //echo "in ajax";
        include 'stock_stockVerification.php';
        break;
    
    case 'stock_varification_save':
        include 'stock_stockvarificationSave.php';
        break;
    
    
    case 'stockBalance':
        //echo "in ajax";
        include 'stock_stockBalance.php';
        break;
    
    
//    case 'stock_showAddSupplier':
//        //echo "in ajax";
//        include 'stock_showAddSupplier.php';
//        break;
    
    
    case 'save_new_supplier':
        //echo "in ajax";
        include 'stock_save_new_supplier.php';
        break;



    /*     * ************* */
    /* User Profile Module */
    /*     * ************* */
    
     case 'editUserProfile':
        include 'profile_editProfile.php';
        break;
    
    case 'profile_saveEdited':
        include 'profile_editProfile_action.php';
        break;
    
    case 'profile_changePassword':
        include 'profile_changePassword.php';
        break;
    
    case 'changePasswordAction':
        include 'profile_changePasswordAction.php';
        break;
    
    case 'profile_shortcutMenu':
        include 'profile_shortcutMenu.php';
        break;
    
    case 'save_shortcut_menu':
        include 'profile_save_shortcut_menu.php';
        break;


    

    
    
    /*************************/
    /* Administration Module */
    /*************************/    
    
    case 'admin_addNewUser':
        include 'admin_addNewUser.php';
        break;
    
     case 'admin_addUserAction':
        include 'admin_addNewUser_action.php';
        break;
    
     case 'admin_userManagement':
        include 'admin_userManagement.php';
        break;
    
    case 'admin_serviceTeam':
        include 'admin_serviceTeam.php';
        break;
    
   
    
    case 'userMx_viewUserInfo':
        include 'admin_userManagement_userData.php';
        break;
    
    case 'updateUserProfile':
        include 'admin_userManagement_action.php';
        break;
    
    case 'admin_manageKnowledgeBank':
        include 'admin_manageKb.php';
        break;
    
    case 'manageKB_open':
        include 'admin_manageKB_categoryResponse.php';
        break;
    
    case 'editKbItem':
        include 'admin_editKbItem.php';
        break;
    
    case 'editKbItemSave':
        include 'admin_manageKB_categoryResponse.php';
        break;
    
    case 'removeKbItem':
        include 'admin_manageKB_categoryResponse.php';
        break;
    
    case 'serviceTeam_add':
        include 'admin_serviceTeam_add.php';
        break;
    
    /*************************/
    /* Pharmacy Module */
    /*************************/    
    
    
    case 'addPharmacyInvoice':
        include 'bill_invoice.php';
        break;
    
    case 'show-pharmacy-inprogress-bill-table':
        include 'pharmacy_in-progress-bill-table.php';
        break;
    
    
    case 'openPharmacyInprogressInvoice':
        include 'bill_invoice.php';
        break;
    
    case 'open-pharmacy-credit-bills':
        include 'pharmacy_credit-bill-table.php';
        break;
    
    case 'openPharmacyCreditInvoice':
        include 'bill_invoice.php';
        break;
    
    case 'selectClientForInvoice':
        include 'pharmacy_selectClientForInvoice.php';
        break;
    
    case 'selectClient_forPharmacyInvoice':
        include 'pharmacy_selectClient_forPharmacyInvoice.php';
        break;
    
    case 'saveClientForParmacyInvoice':
        include 'pharmacy_saveClientForParmacyInvoice.php';
        break;
    
    case 'savePetIDForPharmacyInvoice':
        include 'pharmacy_savePetIDForPharmacyInvoice.php';
        break;
    
    
    
    
    /*************************/
    /*======= Lab Module ====*/
    /*************************/    
    
    
    case 'order-investigation':
        include 'lab_add_checkPetID.inc.php';
        break;
    
    case 'show-lab-invoice':
        include 'bill_invoice.php';
        break;
    
     case 'selectPet_forAddInvestigation':
        include 'lab_pet_result_forOrderInvestigation.php';
        break;
    
    case 'main_receiveSample':
        include 'lab_receiveSample.php';
        break;
    
    case 'main_addResult':
        include 'lab_addResult.php';
        break;
    
    case 'main_viewResult':
        include 'lab_viewResult.php';
        break;
    
    case 'addInvestigationResult':
        include 'lab_addInvestigationResult.php';
        break;
    
    case 'saveInvestigationResult':
        include 'lab_saveInvestigationResult.php';
        break;
    
    case 'print_investigation_results':
        include 'lab_print_investigation_results.php';
        break;
    
    case 'print_update_ix_result':
        include 'lab_print_update_ix_result.php';
        break;
    
    case 'markAsReceived':
        include 'lab_markAsReceived.php';
        break;
    
    case 'confirmasreceived':
        include 'lab_confirmasreceived.php';
        break;

    
    
    
    
    /*************************/
    /*======= Investigation Module ====*/
    /*************************/ 
    
    case 'main_addInvestigation':
        include 'ix_addInvestigation.php';
        break;
    
    case 'saveInvestigation':
        include 'ix_saveInvestigation.php';
        break;
    
    case 'main_listEditInvestigation':
        include 'ix_listEditInvestigation.php';
        break;
    
    case 'investigation_info':
        include 'ix_investigation_info.php';
        break;
    
    case 'investigation_edit':
        include 'ix_investigation_edit.php';
        break;
    
    case 'saveEditInvestigation':
        include 'ix_saveEditInvestigation.php';
        break;
    
    case 'main_addComponent':
        include 'ix_addComponent.php';
        break;
    
     case 'loadComponentDetail':
        include 'ix_loadComponentDetail.php';
        break;
    
    case 'saveComponent':
        include 'ix_loadComponentDetail.php';
        break;
    
    case 'removeComponent':
        include 'ix_loadComponentDetail.php';
        break;
    
    case 'modal_editComponent':
        include 'ix_modal_editComponent.php';
        break;
    
    case 'saveEditedComponent':
        include 'ix_loadComponentDetail.php';
        break;
    

    
    
    
    
    
    
    
    
    case 'openNewInvoice':
        include 'invoice.inc.php';
        break;

    case 'saveInvoiceData':
        //echo 'saveInvoiceData';
        include 'saveInvoiceData.inc.php';
        break;

    case 'showSelectClientInModalForInvoice':
        //echo 'in ajux';
        include 'selectClientForInvoice.inc.php';
        break;

    case 'selectClient_forInvoice':
        include 'selectClient_result_forInvoice.inc.php';
        break;

    case 'showClientAndPetDetailsForInvoice':
        include 'showClientAndPetDetailsForInvoice.inc.php';
        break;

    
//    test case


    default:
        break;
}