<!DOCTYPE html>
<!--
PetsVCare V1.0
14/01/2018
HiSP Pvt Ltd (c) 2018
Developer: Priyanga Senanayaka
-->
<?php
session_start();
// load the database
require_once 'db.inc.php';

// load the function
require_once 'function.inc.php';

//load the core
require_once 'core.inc.php';

//clear session if logout link clicked
if (filter_input(INPUT_GET, 'lo') && (filter_input(INPUT_GET, 'lo') == 'y')) {

//create a log query - Logout
    if (isset($_SESSION['pvcUserID'])) {
        
        //log entry
        include_once 'function.inc.php';
        writeLog($conn, '', "logout", "success");
        session_destroy();
    }
}

//filtering incoming values (username & Password)
$username = (filter_input(INPUT_POST, 'username')) ? trim(filter_input(INPUT_POST, 'username')) : '';
$password = (filter_input(INPUT_POST, 'password')) ? trim(filter_input(INPUT_POST, 'password')) : '';

//checking inputs using above function
$usr = check_input($conn, $username);
$pwd = check_input($conn, $password);

if (filter_input(INPUT_POST, 'submit') === 'Login') {
    $sql = 'SELECT userID, title, otherNames, lastName, displayName, active, logged FROM user WHERE ' .
        'uName = "' . mysqli_real_escape_string($conn, $usr) . '" AND ' .
        'pwd = PASSWORD("' . mysqli_real_escape_string($conn, $pwd) . '") AND active = "y"';
    $result = $conn->query($sql) or die($conn->error);
        
    //to check whether a record is avaivable
    if ($result->num_rows > 0) {
        //login success
        while($row = $result->fetch_assoc()) {
            //log entry
            include_once 'function.inc.php';
            writeLog($conn, $sql, "login", "success");
            
            //setting session variables
            $_SESSION['pvcDisplayName'] = $row['displayName'];
            $_SESSION['pvcUserID'] = $row['userID'];
            $_SESSION['pvcLogged'] = 1;
            
            $userID = $row['userID'];
            
            //setting session variable for client module previlages
            $sql = "SELECT 
                        previlage_previlageID 
                    FROM 
                        user_module_previlage
                    WHERE
                        module_moduleID = 1 AND user_userID = ".$userID;
            $result = $conn->query($sql) or die($conn->error);
            $row = $result->fetch_assoc();
            $_SESSION['pvc_mod_client'] = $row['previlage_previlageID'];
            
            //setting session variable for pet module previlages
            $sql = "SELECT 
                        previlage_previlageID 
                    FROM 
                        user_module_previlage
                    WHERE
                        module_moduleID = 2 AND user_userID = ".$userID;
            $result = $conn->query($sql) or die($conn->error);
            $row = $result->fetch_assoc();
            $_SESSION['pvc_mod_pet'] = $row['previlage_previlageID'];
            
            //setting session variable for visit module previlages
            $sql = "SELECT 
                        previlage_previlageID 
                    FROM 
                        user_module_previlage
                    WHERE
                        module_moduleID = 3 AND user_userID = ".$userID;
            $result = $conn->query($sql) or die($conn->error);
            $row = $result->fetch_assoc();
            $_SESSION['pvc_mod_visit'] = $row['previlage_previlageID'];
            
            //setting session variable for billing module previlages
            $sql = "SELECT 
                        previlage_previlageID 
                    FROM 
                        user_module_previlage
                    WHERE
                        module_moduleID = 4 AND user_userID = ".$userID;
            $result = $conn->query($sql) or die($conn->error);
            $row = $result->fetch_assoc();
            $_SESSION['pvc_mod_bill'] = $row['previlage_previlageID'];
            
            //setting session variable for item module previlages
            $sql = "SELECT 
                        previlage_previlageID 
                    FROM 
                        user_module_previlage
                    WHERE
                        module_moduleID = 7 AND user_userID = ".$userID;
            $result = $conn->query($sql) or die($conn->error);
            $row = $result->fetch_assoc();
            $_SESSION['pvc_mod_item'] = $row['previlage_previlageID'];
            
            //setting session variable for stock module previlages
            $sql = "SELECT 
                        previlage_previlageID 
                    FROM 
                        user_module_previlage
                    WHERE
                        module_moduleID = 8 AND user_userID = ".$userID;
            $result = $conn->query($sql) or die($conn->error);
            $row = $result->fetch_assoc();
            $_SESSION['pvc_mod_stock'] = $row['previlage_previlageID'];
            
            //setting session variable for userProfile previlages
            $sql = "SELECT 
                        previlage_previlageID 
                    FROM 
                        user_module_previlage
                    WHERE
                        module_moduleID = 9 AND user_userID = ".$userID;
            $result = $conn->query($sql) or die($conn->error);
            $row = $result->fetch_assoc();
            $_SESSION['pvc_mod_profile'] = $row['previlage_previlageID'];
            
            //setting session variable for administration previlages
            $sql = "SELECT 
                        previlage_previlageID 
                    FROM 
                        user_module_previlage
                    WHERE
                        module_moduleID = 10 AND user_userID = ".$userID;
            $result = $conn->query($sql) or die($conn->error);
            $row = $result->fetch_assoc();
            $_SESSION['pvc_mod_admin'] = $row['previlage_previlageID'];
            
            
            //setting session variable for investigation module previlages
            $sql = "SELECT 
                        previlage_previlageID 
                    FROM 
                        user_module_previlage
                    WHERE
                        module_moduleID = 11 AND user_userID = ".$userID;
            $result = $conn->query($sql) or die($conn->error);
            $row = $result->fetch_assoc();
            $_SESSION['pvc_mod_ix'] = $row['previlage_previlageID'];
            
            //setting session variable for investigation module previlages
            $sql = "SELECT 
                        previlage_previlageID 
                    FROM 
                        user_module_previlage
                    WHERE
                        module_moduleID = 12 AND user_userID = ".$userID;
            $result = $conn->query($sql) or die($conn->error);
            $row = $result->fetch_assoc();
            $_SESSION['pvc_mod_report'] = $row['previlage_previlageID'];
            
            
            
            
            
            
             //setting session variable for billing module previlages
            $sql = "SELECT 
                        previlage_previlageID 
                    FROM 
                        user_module_previlage
                    WHERE
                        module_moduleID = 5 AND user_userID = ".$userID;
            $result = $conn->query($sql) or die($conn->error);
            $row = $result->fetch_assoc();
            $_SESSION['pvc_mod_lab'] = $row['previlage_previlageID'];
            
             //setting session variable for billing module previlages
            $sql = "SELECT 
                        previlage_previlageID 
                    FROM 
                        user_module_previlage
                    WHERE
                        module_moduleID = 6 AND user_userID = ".$userID;
            $result = $conn->query($sql) or die($conn->error);
            $row = $result->fetch_assoc();
            $_SESSION['pvc_mod_pharmacy'] = $row['previlage_previlageID'];
            
            
            //redirect to home page
            ?>
            <script type="text/javascript">
                window.location.href = 'index.php';
            </script>
            <?php
            mysql_free_result($result);
            $conn->close();
            die();
        }       
    } else {
        //login failed
        $failed = 'yes';
        
        //log login failed
        //log entry
        include_once 'function.inc.php';
        writeLog($conn, $sql, "login attempt", "failed");
        $conn->close();
    }
}
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PetsVcare</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        .card-container.card {
            max-width: 350px;
            padding: 40px 40px;
        }

        .btn {
            font-weight: 700;
            height: 36px;
            -moz-user-select: none;
            -webkit-user-select: none;
            user-select: none;
            cursor: default;
        }

        .card {
            background-color: #F7F7F7;
            /* just in case there no content*/
            padding: 20px 25px 30px;
            margin: 0 auto 25px;
            margin-top: 50px;
            /* shadows and rounded borders */
            -moz-border-radius: 2px;
            -webkit-border-radius: 2px;
            border-radius: 2px;
            -moz-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
            -webkit-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
            box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
        }

        .profile-img-card {
            width: 96px;
            height: 96px;
            margin: 0 auto 10px;
            display: block;
            -moz-border-radius: 50%;
            -webkit-border-radius: 50%;
            border-radius: 50%;
        }

        .profile-name-card {
            font-size: 16px;
            font-weight: bold;
            text-align: center;
            margin: 10px 0 0;
            min-height: 1em;
        }

        .reauth-email {
            display: block;
            color: #404040;
            line-height: 2;
            margin-bottom: 10px;
            font-size: 14px;
            text-align: center;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            -moz-box-sizing: border-box;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
        }

        .form-signin #inputEmail,
        .form-signin #inputPassword {
            direction: ltr;
            height: 44px;
            font-size: 16px;
        }

        .form-signin input[type=email],
        .form-signin input[type=password],
        .form-signin input[type=text],
        .form-signin button {
            width: 100%;
            display: block;
            margin-bottom: 10px;
            z-index: 1;
            position: relative;
            -moz-box-sizing: border-box;
            -webkit-box-sizing: border-box;
            box-sizing: border-box;
        }

        .form-signin .form-control:focus {
            border-color: rgb(104, 145, 162);
            outline: 0;
            -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075),0 0 8px rgb(104, 145, 162);
            box-shadow: inset 0 1px 1px rgba(0,0,0,.075),0 0 8px rgb(104, 145, 162);
        }

        .btn.btn-signin {
            /*background-color: #4d90fe; */
            background-color: rgb(104, 145, 162);
            /* background-color: linear-gradient(rgb(104, 145, 162), rgb(12, 97, 33));*/
            padding: 0px;
            font-weight: 700;
            font-size: 14px;
            height: 36px;
            -moz-border-radius: 3px;
            -webkit-border-radius: 3px;
            border-radius: 3px;
            border: none;
            -o-transition: all 0.218s;
            -moz-transition: all 0.218s;
            -webkit-transition: all 0.218s;
            transition: all 0.218s;
            margin-top: 20px;
        }

        .btn.btn-signin:hover,
        .btn.btn-signin:active,
        .btn.btn-signin:focus {
            background-color: rgb(12, 97, 33);
        }

        .forgot-password {
            color: rgb(104, 145, 162);
        }

        .forgot-password:hover,
        .forgot-password:active,
        .forgot-password:focus{
            color: rgb(12, 97, 33);
        }

        .topPadding{
            padding-top: 20px;
        }

        img.logo {
            width: 100px;
        }

        .companyName {
            font-size: 1.4em;
            color: white;
        }

        .slogan {
            font-size: 1.2em;
            color:#bfd9f2 ;
        /*    font-style: italic;*/
        }
        body {
            background-color:#1d5288 ;
        }

        .footerTextLeft {
            color: #6b90b8;
            font-size: 1em;
            position: fixed; 
            left:10px; 
            bottom: 3px;
        }

        .footerTextRight {
            color: #6b90b8;
            font-size: 1em;
            position: fixed; 
            right:10px; 
            bottom: 3px;
        }       
    </style>
</head>

<body>
    <div class="container-fluid col-sm-12">
        <div class="col-sm-2 text-right topPadding" style=''>
            <img class="logo" src="image/petlogo1.png"/>
        </div>
        <div class="col-sm-10 text-left topPadding" style="height: 100px; position: relative; bottom: 0; left: 0;">
            <div style="position: absolute; bottom: 0; left: 0;">
                <span class="companyName"> Pets V Care (Pvt) Ltd.</span>
                <br/>
                <span class="slogan"> "Place for Best Pet Care"</span>
            </div>
        </div>
    </div>
    <div class="col-sm-12">
        <div class="card card-container">
<!--            <img id="profile-img" class="profile-img-card" src="//ssl.gstatic.com/accounts/ui/avatar_2x.png" />-->
            <img id="profile-img" class="profile-img-card" src="image/avatar_login.png" />
            <!--<p id="profile-name" class="profile-name-card"></p>-->
            
            <!-- login form -->
            <form class="form-signin" action="login.php" method="POST">
                <span id="reauth-email" class="reauth-email"></span>
                <input  type="text" id="inputUN" class="form-control" placeholder="User Name" required autofocus name="username">
                <input  type="password" id="inputPW" class="form-control" placeholder="Password" name="password" required>
<!--                <input tabindex="3" type="checkbox" value="rememberme" name="remember"> Remember me-->
                <input type="submit"  class="btn btn-lg btn-primary btn-block btn-signin" value="Login" name="submit" id="btnSubmit">
                <br/>
                
                <?php
                    if (isset($failed) && ($failed == 'yes')){
                        echo '<div class="alert alert-danger" style="margin-bottom:0px;">';
                        echo '<strong>Login Failed!</strong> <br/> Incorrect username and/or password.';
                        echo '</div>'; 
                    }
                    $failed = '';
                ?>
                
                
                
            
            </form>
            
            <script>
//                to submit form when enter
                var input = document.getElementById("inputPW");
                input.addEventListener("keyup", function(event) {
                    event.preventDefault();
                    if (event.keyCode === 13) {
                        document.getElementById("btnSubmit").click();
                    }
                });
                var input2 = document.getElementById("inputUN");
                input2.addEventListener("keyup", function(event) {
                    event.preventDefault();
                    if (event.keyCode === 13) {
                        document.getElementById("btnSubmit").click();
                    }
                });
            </script>
            
        </div><!-- /card-container -->
    </div><!-- /container -->
    
    <div class='footerTextLeft'>
        HiSP (Sri Lanka) Pvt Ltd - web: www.hisp.lk
    </div>
    
    <div class='footerTextRight'>
        All Rights Reserved (c) 2018
    </div>
           
</body>
</html>