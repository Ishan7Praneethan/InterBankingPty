<?php
 session_start();
 if (!isset($_SESSION['pvcLogged'])) {
     header("Location:login.php");
       die();
 }
$userID = $_SESSION['pvcUserID'];

?>
<!--
PetsVCare V1.0
17/12/2017
HiSP Pvt Ltd (c) 2017
Developer: Priyanga Senanayaka
-->
<!DOCTYPE html>
<html lang="en">
<head>
	<title>PetsVcare</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
        <?php
            include_once 'core.inc.php';
            include_once 'function.inc.php';
            include_once 'db.inc.php';
        ?>
	  
	<script type="text/javascript">
            window.onload = window.onresize = function () {
                    //getting rendered height of elements
                    var htheader = $('#divheader').height();
                    var htmenu = $('#divmenu').height();			
                    var htfooter = $('#divfooter').height();
                    
                    //set height of left navi
                    var left = document.getElementById("leftnav");
                    var height = window.innerHeight;
                    height = height - htheader - htfooter - htmenu - 2;
                    left.style.height = height + "px";

                    //set height of main cantent area
                    var content = document.getElementById("divContent");
                    content.style.height = height + "px";
            };	
            
            $(function () {
                $("#logout-link").on("click", function () {
                    //alert('aaa');
                    $(location).attr('href', 'login.php?lo=y');
                });
            });
            
	</script>
        
        
        
        <style>
            @media screen and (max-width: 600px) {
  #leftnav {
    display:none;
/*    clear: both;
    float: left;
    margin: 10px auto 5px 20px;
    width: 28%;
    display: none;*/
  }
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
}




        </style>
</head>

<body>
<!--    Address bar and the header-->
    <div id="divheader" class="container-fluid">    
	<div class="row">
	  <div class="col-sm-4 text-left addressbar">PetsVcare (Pvt) Ltd.</div>
	  <div id="clock" class="col-sm-4 text-center addressbar"></div>
          <div class="col-sm-4 text-right addressbar">Welcome <?php if (isset($_SESSION['pvcDisplayName'])) {echo $_SESSION['pvcDisplayName'];} ?>! | <a id="logout-link"><span class="glyphicon glyphicon-log-out"></span> Logout</a></div>
	</div>
    </div>
  
<!--    Top Menu bar-->    
    <nav class="navbar navbar-default topnav" style="margin-bottom: 0px; border-radius: 0px; min-height: 20px">
        <div id="divmenu" class="container-fluid">
            <ul class="nav navbar-nav">
            <!--Menu-1 @ Top Menu bar-->  
            
                <li>
                    <a id="main_home" class="smallpadding" href="javascript:void(0);"><span class="glyphicon glyphicon-home"></span></a>
                </li>
                <li>
                    <a id="main_noticeBoard" class="smallpadding" href="javascript:void(0);" onlick='$("#divContent").empty();'><span class="glyphicon glyphicon-th-large"></span></a>
                </li>
                <li class="dropdown <?php echo isset($_SESSION['pvc_mod_client']) && $_SESSION['pvc_mod_client'] > 1 ? '' : 'display-none' ?>"><a class="dropdown-toggle smallpadding" data-toggle="dropdown" href="#">Clients  <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                      <li class="<?php echo isset($_SESSION['pvc_mod_client']) && $_SESSION['pvc_mod_client'] > 2 ? '' : 'display-none' ?>"><a id="main_addClient" href="javascript:void(0);">Add Client</a></li>
                      <li class="<?php echo isset($_SESSION['pvc_mod_client']) && $_SESSION['pvc_mod_client'] > 1 ? '' : 'display-none' ?>"><a id="main_searchClient" href="javascript:void(0);">Search Client</a></li>
                      <li class="<?php echo isset($_SESSION['pvc_mod_client']) && $_SESSION['pvc_mod_client'] > 1 ? '' : 'display-none' ?>"><a id="main_listClient" href="javascript:void(0);">List Clients</a></li>
                      <li class="<?php echo isset($_SESSION['pvc_mod_client']) && $_SESSION['pvc_mod_client'] > 3 ? '' : 'display-none' ?>"><a id="main_editClient" href="javascript:void(0);">Edit Client</a></li>
                      <li class="<?php echo isset($_SESSION['pvc_mod_client']) && $_SESSION['pvc_mod_client'] > 1 ? '' : 'display-none' ?>"><a id="main_clientDashboard" href="javascript:void(0);">Client Dashboard</a></li>
                      
                    </ul>
                </li>
            <!--Menu-2 @ Top Menu bar-->
                <li class="dropdown <?php echo isset($_SESSION['pvc_mod_pet']) && $_SESSION['pvc_mod_pet'] > 1 ? '' : 'display-none' ?>"><a class="dropdown-toggle smallpadding" data-toggle="dropdown" href="#">Pets <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li class="<?php echo isset($_SESSION['pvc_mod_pet']) && $_SESSION['pvc_mod_pet'] > 2 ? '' : 'display-none' ?>"><a id="main_addPet" href="javascript:void(0);">Add Pet</a></li>
                        <li class="<?php echo isset($_SESSION['pvc_mod_pet']) && $_SESSION['pvc_mod_pet'] > 1 ? '' : 'display-none' ?>"><a id="main_SearchPet" href="javascript:void(0);">Search Pet</a></li>
                        <li class="<?php echo isset($_SESSION['pvc_mod_pet']) && $_SESSION['pvc_mod_pet'] > 1 ? '' : 'display-none' ?>"><a id="main_ListPet" href="javascript:void(0);">List Pets</a></li>
                        <li class="<?php echo isset($_SESSION['pvc_mod_pet']) && $_SESSION['pvc_mod_pet'] > 3 ? '' : 'display-none' ?>"><a id="main_EditPet" href="javascript:void(0);">Edit Pets</a></li>
                        <li class="<?php echo isset($_SESSION['pvc_mod_pet']) && $_SESSION['pvc_mod_pet'] > 1 ? '' : 'display-none' ?>"><a id="main_petDashboard" href="javascript:void(0);">Pet Dashboard</a></li>
                        <li class="<?php echo isset($_SESSION['pvc_mod_pet']) && $_SESSION['pvc_mod_pet'] > 3 ? '' : 'display-none' ?>"><a id="main_TransferPet" href="javascript:void(0);">Pet Transfer</a></li>
                    </ul>
                </li>
                
                <!--Menu-3 @ Top Menu bar-->
                <li class="dropdown <?php echo isset($_SESSION['pvc_mod_visit']) && $_SESSION['pvc_mod_visit'] > 1 ? '' : 'display-none' ?>"><a class="dropdown-toggle smallpadding" data-toggle="dropdown" href="#">Visit<span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li class="<?php echo isset($_SESSION['pvc_mod_visit']) && $_SESSION['pvc_mod_visit'] > 2 ? '' : 'display-none' ?>"><a id="main_addVisit" href="javascript:void(0);">Add Visit</a></li>
                        <li class="<?php echo isset($_SESSION['pvc_mod_visit']) && $_SESSION['pvc_mod_visit'] > 1 ? '' : 'display-none' ?>"><a id="main_viewVisit" href="javascript:void(0);">View Visit</a></li>
                    </ul>
                </li>
                
                <!--Menu-4 @ Top Menu bar-->
                <li class="dropdown <?php echo isset($_SESSION['pvc_mod_bill']) && $_SESSION['pvc_mod_bill'] > 1 ? '' : 'display-none' ?>"><a class="dropdown-toggle smallpadding" data-toggle="dropdown" href="#">Billing<span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li class="<?php echo isset($_SESSION['pvc_mod_bill']) && $_SESSION['pvc_mod_bill'] > 2 ? '' : 'display-none' ?>"><a id="main_visitsForBilling" href="javascript:void(0);">Pending Bills</a></li>
                        <li class="<?php echo isset($_SESSION['pvc_mod_bill']) && $_SESSION['pvc_mod_bill'] > 2 ? '' : 'display-none' ?>"><a id="main_showCreditBills" href="javascript:void(0);">List Credit Bills</a></li>
                        <li class="<?php echo isset($_SESSION['pvc_mod_bill']) && $_SESSION['pvc_mod_bill'] > 2 ? '' : 'display-none' ?>"><a id="main_listClinicBills" href="javascript:void(0);">Search Clinic Bills</a></li>
                        <li class="<?php echo isset($_SESSION['pvc_mod_bill']) && $_SESSION['pvc_mod_bill'] > 2 ? '' : 'display-none' ?>"><a id="main_advanceBill" href="javascript:void(0);">Advance Bill</a></li>
                         <li class="<?php echo isset($_SESSION['pvc_mod_bill']) && $_SESSION['pvc_mod_bill'] > 2 ? '' : 'display-none' ?>"><a id="main_listAdvanceBill" href="javascript:void(0);">Search Advance Bills</a></li>
<!--                        <li class="<?php echo isset($_SESSION['pvc_mod_bill']) && $_SESSION['pvc_mod_bill'] > 1 ? '' : 'display-none' ?>"><a id="main_listBills" href="javascript:void(0);">List Bills</a></li>-->
                    </ul>
                </li>
                
                <!--Menu-5 @ Top Menu bar-->
                <li class="dropdown <?php echo isset($_SESSION['pvc_mod_item']) && $_SESSION['pvc_mod_item'] > 1 ? '' : 'display-none' ?>"><a class="dropdown-toggle smallpadding" data-toggle="dropdown" href="#">Billing Items<span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li class="<?php echo isset($_SESSION['pvc_mod_item']) && $_SESSION['pvc_mod_item'] > 2 ? '' : 'display-none' ?>"><a id="main_addBillingItem" href="javascript:void(0);">Add Billing Item</a></li>
                        <li class="<?php echo isset($_SESSION['pvc_mod_item']) && $_SESSION['pvc_mod_item'] > 1 ? '' : 'display-none' ?>"><a id="main_listEditItem" href="javascript:void(0);">List/Edit Item</a></li>
                    </ul>
                </li>
                
                <!--Menu-5 @ Top Menu bar-->
                <li class="dropdown <?php echo isset($_SESSION['pvc_mod_ix']) && $_SESSION['pvc_mod_ix'] > 1 ? '' : 'display-none' ?>"><a class="dropdown-toggle smallpadding" data-toggle="dropdown" href="#">Investigation<span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li class="<?php echo isset($_SESSION['pvc_mod_ix']) && $_SESSION['pvc_mod_ix'] > 2 ? '' : 'display-none' ?>"><a id="main_addInvestigation" href="javascript:void(0);">Add Investigation</a></li>
                        <li class="<?php echo isset($_SESSION['pvc_mod_ix']) && $_SESSION['pvc_mod_ix'] > 2 ? '' : 'display-none' ?>"><a id="main_listEditInvestigation" href="javascript:void(0);">List/Edit Investigation</a></li>
                        <li class="<?php echo isset($_SESSION['pvc_mod_ix']) && $_SESSION['pvc_mod_ix'] > 2 ? '' : 'display-none' ?>"><a id="main_addComponent" href="javascript:void(0);">Manage Components</a></li>
<!--                        <li class="<?php echo isset($_SESSION['pvc_mod_ix']) && $_SESSION['pvc_mod_ix'] > 1 ? '' : 'display-none' ?>"><a id="main_listEditComponent" href="javascript:void(0);">List/Edit Components</a></li>-->
                    </ul>
                </li>
                
                <!--Menu-5 @ Top Menu bar-->
                <li class="dropdown <?php echo isset($_SESSION['pvc_mod_stock']) && $_SESSION['pvc_mod_stock'] > 1 ? '' : 'display-none' ?>"><a class="dropdown-toggle smallpadding" data-toggle="dropdown" href="#">Stock<span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li class="<?php echo isset($_SESSION['pvc_mod_stock']) && $_SESSION['pvc_mod_stock'] > 2 ? '' : 'display-none' ?>"><a id="main_stockReceiving" href="javascript:void(0);">Receiving</a></li>
                        <li class="<?php echo isset($_SESSION['pvc_mod_stock']) && $_SESSION['pvc_mod_stock'] > 2 ? '' : 'display-none' ?>"><a id="main_stockDistribution" href="javascript:void(0);">Distribution</a></li>
                        <li class="<?php echo isset($_SESSION['pvc_mod_stock']) && $_SESSION['pvc_mod_stock'] > 2 ? '' : 'display-none' ?>"><a id="main_stockTransfer" href="javascript:void(0);">Transfer</a></li>
                        <li class="<?php echo isset($_SESSION['pvc_mod_stock']) && $_SESSION['pvc_mod_stock'] > 3 ? '' : 'display-none' ?>"><a id="main_stockVerification" href="javascript:void(0);">Verification</a></li>
                        <li class="<?php echo isset($_SESSION['pvc_mod_stock']) && $_SESSION['pvc_mod_stock'] > 1 ? '' : 'display-none' ?>"><a id="main_stockBalance" href="javascript:void(0);">View Balance</a></li>
                    </ul>
                </li>             
               
                
                
                <!--Menu-6 @ Top Menu bar-->
                <li class="dropdown <?php echo isset($_SESSION['pvc_mod_pharmacy']) && $_SESSION['pvc_mod_pharmacy'] > 1 ? '' : 'display-none' ?>"><a class="dropdown-toggle smallpadding" data-toggle="dropdown" href="#">Pharmacy<span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li class="<?php echo isset($_SESSION['pvc_mod_pharmacy']) && $_SESSION['pvc_mod_pharmacy'] > 2 ? '' : 'display-none' ?>"><a id="main_pharmacyBilling" href="javascript:void(0);">New Bill</a></li>
                        <li class="<?php echo isset($_SESSION['pvc_mod_pharmacy']) && $_SESSION['pvc_mod_pharmacy'] > 2 ? '' : 'display-none' ?>"><a id="main_pharmacyInProgressBills" href="javascript:void(0);">In-progress Bills</a></li>
                        <li class="<?php echo isset($_SESSION['pvc_mod_pharmacy']) && $_SESSION['pvc_mod_pharmacy'] > 2 ? '' : 'display-none' ?>"><a id="main_pharmacyCreditBills" href="javascript:void(0);">Credit Bills</a></li>
<!--                        <li class="<?php echo isset($_SESSION['pvc_mod_pharmacy']) && $_SESSION['pvc_mod_pharmacy'] > 1 ? '' : 'display-none' ?>"><a id="main_ListVisit" href="javascript:void(0);">Returns</a></li>-->
                        <li class="<?php echo isset($_SESSION['pvc_mod_pharmacy']) && $_SESSION['pvc_mod_pharmacy'] > 1 ? '' : 'display-none' ?>"><a id="main_pharmacyStockBalance" href="javascript:void(0);">Stock Balance</a></li>
                        
                    </ul>
                </li>
                
                <!--Menu-5 @ Top Menu bar-->
                <li class="dropdown <?php echo isset($_SESSION['pvc_mod_lab']) && $_SESSION['pvc_mod_lab'] > 1 ? '' : 'display-none' ?>"><a class="dropdown-toggle smallpadding" data-toggle="dropdown" href="#">Laboratory<span class="caret"></span></a>
                    <ul class="dropdown-menu">
<!--                        <li class="<?php echo isset($_SESSION['pvc_mod_lab']) && $_SESSION['pvc_mod_lab'] > 2 ? '' : 'display-none' ?>"><a id="main_orderInvestigation" href="javascript:void(0);">Order Investigation</a></li>-->
                        <li class="<?php echo isset($_SESSION['pvc_mod_lab']) && $_SESSION['pvc_mod_lab'] > 2 ? '' : 'display-none' ?>"><a id="main_receiveSample" href="javascript:void(0);">Receive Sample</a></li>
                        <li class="<?php echo isset($_SESSION['pvc_mod_lab']) && $_SESSION['pvc_mod_lab'] > 3 ? '' : 'display-none' ?>"><a id="main_addResult" href="javascript:void(0);">Add Result</a></li>
<!--                        <li class="<?php echo isset($_SESSION['pvc_mod_lab']) && $_SESSION['pvc_mod_lab'] > 1 ? '' : 'display-none' ?>"><a id="main_printReport" href="javascript:void(0);">Print Report</a></li>-->
                        <li class="<?php echo isset($_SESSION['pvc_mod_lab']) && $_SESSION['pvc_mod_lab'] > 1 ? '' : 'display-none' ?>"><a id="main_viewResult" href="javascript:void(0);">View/Reprint Results</a></li>
                    </ul>
                </li>
                
                <!--Menu-6 @ Top Menu bar-->
<!--                <li class="dropdown <?php echo isset($_SESSION['pvc_mod_report']) && $_SESSION['pvc_mod_report'] > 1 ? '' : 'display-none' ?>"><a class="dropdown-toggle smallpadding" data-toggle="dropdown" href="#">Reports<span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li class="<?php echo isset($_SESSION['pvc_mod_report']) && $_SESSION['pvc_mod_report'] > 2 ? '' : 'display-none' ?>"><a id="main_pharmacyBilling" href="javascript:void(0);">Sub Menu 1</a></li>
                        <li class="<?php echo isset($_SESSION['pvc_mod_report']) && $_SESSION['pvc_mod_report'] > 1 ? '' : 'display-none' ?>"><a id="main_ListVisit" href="javascript:void(0);">Sub Menu 2</a></li>
                        <li class="<?php echo isset($_SESSION['pvc_mod_report']) && $_SESSION['pvc_mod_report'] > 1 ? '' : 'display-none' ?>"><a id="main_ListVisit" href="javascript:void(0);">Sub Menu 3</a></li>
                        <li class="<?php echo isset($_SESSION['pvc_mod_report']) && $_SESSION['pvc_mod_report'] > 1 ? '' : 'display-none' ?>"><a id="main_pharmacyStockBalance" href="javascript:void(0);">Sub Menu 4</a></li>
                        
                    </ul>
                </li>-->
                
                <!--Menu-7 @ Top Menu bar-->
                <li class="dropdown <?php echo isset($_SESSION['pvc_mod_admin']) && $_SESSION['pvc_mod_admin'] > 1 ? '' : 'display-none' ?>"><a class="dropdown-toggle smallpadding" data-toggle="dropdown" href="#">Administration<span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li class="<?php echo isset($_SESSION['pvc_mod_admin']) && $_SESSION['pvc_mod_admin'] > 2 ? '' : 'display-none' ?>"><a id="main_addNewUser" href="javascript:void(0);">Add New User</a></li>
                        <li class="<?php echo isset($_SESSION['pvc_mod_admin']) && $_SESSION['pvc_mod_admin'] > 3 ? '' : 'display-none' ?>"><a id="main_userManagement" href="javascript:void(0);">User Management</a></li>
                        <li class="<?php echo isset($_SESSION['pvc_mod_admin']) && $_SESSION['pvc_mod_admin'] > 3 ? '' : 'display-none' ?>"><a id="serviceTeam" href="javascript:void(0);">Service Team</a></li>
                        <li class="<?php echo isset($_SESSION['pvc_mod_admin']) && $_SESSION['pvc_mod_admin'] > 1 ? '' : 'display-none' ?>"><a id="main_knowledgeBank" href="javascript:void(0);">Knowledge Bank</a></li>
                        
                    </ul>
                </li>
                
                <!--Menu-7 @ Top Menu bar-->
                <li class="dropdown <?php echo isset($_SESSION['pvc_mod_profile']) && $_SESSION['pvc_mod_profile'] > 2 ? '' : 'display-none' ?>" ><a class="dropdown-toggle smallpadding" data-toggle="dropdown" href="#">My Profile<span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li class="<?php echo isset($_SESSION['pvc_mod_profile']) && $_SESSION['pvc_mod_profile'] > 2 ? '' : 'display-none' ?>"><a id="main_editProfile" href="javascript:void(0);">Edit Profile</a></li>
                        <li class="<?php echo isset($_SESSION['pvc_mod_profile']) && $_SESSION['pvc_mod_profile'] > 2 ? '' : 'display-none' ?>"><a id="main_changePassword" href="javascript:void(0);">Change Password</a></li>
                         <li class="<?php echo isset($_SESSION['pvc_mod_profile']) && $_SESSION['pvc_mod_profile'] > 2 ? '' : 'display-none' ?>"><a id="main_shortcutMenu" href="javascript:void(0);">Shortcut Menu</a></li>
<!--                        <li class=""><a id="main_EditVisit" href="javascript:void(0);">Stock</a></li>-->
                        
                    </ul>
                </li>
                
                
            </ul>
        </div>
    </nav>

<?php
$sql = "SELECT * FROM `shortcutmenu` WHERE user_userID = $userID";
$result = $conn->query($sql);
$rows = mysqli_num_rows($result);
If ($rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $sc1 = $row['sc1'];
        $sc2 = $row['sc2'];
        $sc3 = $row['sc3'];
        $sc4 = $row['sc4'];
        $sc5 = $row['sc5'];
    }
}
?>

    <!--  Side menu - left -->
    <div class="container-fluid">
        <div class="row">
            <div id="leftnav" class="col-sm-1 sidenav container-fluid text-center">
                <!--  square button 1 -->
                <?php
                $sc = $sc1;
                include 'profile_load_shortcut_menu.php';
//                switch ($sc1) {
//                    case '1-1':
//                        echo '<button id="btn_1-1"  type="button" class="btn btn-default square-button bottom-margin-10" >';
//                        echo '<img alt="<add client>" class="button-img" src="image/pic1.png"/><br/>';
//                        echo '<span class="button-text">Add Client</span>';
//                        echo '</button>';
//                        break;
//                    
//                    case '1-2':
//                        echo '<button id="btn_1-2"  type="button" class="btn btn-default square-button bottom-margin-10" >';
//                        echo '<img alt="<add client>" class="button-img" src="image/pic1.png"/><br/>';
//                        echo '<span class="button-text">Client Dashboard</span>';
//                        echo '</button>';
//                        break;
//                    
//                    case '2-1':
//                        echo '<button id="btn_2-1"  type="button" class="btn btn-default square-button bottom-margin-10" >';
//                        echo '<img alt="<add client>" class="button-img" src="image/pic1.png"/><br/>';
//                        echo '<span class="button-text">Add Pet</span>';
//                        echo '</button>';
//                        break;
//                    
//                    case '2-2':
//                        echo '<button id="btn_2-2"  type="button" class="btn btn-default square-button bottom-margin-10" >';
//                        echo '<img alt="<add client>" class="button-img" src="image/pic1.png"/><br/>';
//                        echo '<span class="button-text">Pet Dashboard</span>';
//                        echo '</button>';
//                        break;
//                    
//                    case '3-1':
//                        echo '<button id="btn_3-1"  type="button" class="btn btn-default square-button bottom-margin-10" >';
//                        echo '<img alt="<add client>" class="button-img" src="image/pic1.png"/><br/>';
//                        echo '<span class="button-text">Add Visit</span>';
//                        echo '</button>';
//                        break;
//                    
//                    case '3-2':
//                        echo '<button id="btn_3-2"  type="button" class="btn btn-default square-button bottom-margin-10" >';
//                        echo '<img alt="<add client>" class="button-img" src="image/pic1.png"/><br/>';
//                        echo '<span class="button-text">View Visit</span>';
//                        echo '</button>';
//                        break;
//                    
//                    case '4-1':
//                        echo '<button id="btn_4-1"  type="button" class="btn btn-default square-button bottom-margin-10" >';
//                        echo '<img alt="<add client>" class="button-img" src="image/pic1.png"/><br/>';
//                        echo '<span class="button-text">Clinic Bill</span>';
//                        echo '</button>';
//                        break;
//                    
//                    case '4-2':
//                        echo '<button id="btn_4-2"  type="button" class="btn btn-default square-button bottom-margin-10" >';
//                        echo '<img alt="<add client>" class="button-img" src="image/pic1.png"/><br/>';
//                        echo '<span class="button-text">Credit Bill</span>';
//                        echo '</button>';
//                        break;
//                    
//                    case '4-3':
//                        echo '<button id="btn_4-3"  type="button" class="btn btn-default square-button bottom-margin-10" >';
//                        echo '<img alt="<add client>" class="button-img" src="image/pic1.png"/><br/>';
//                        echo '<span class="button-text">Advance Bill</span>';
//                        echo '</button>';
//                        break;
//                    
//                    case '5-1':
//                        echo '<button id="btn_5-1"  type="button" class="btn btn-default square-button bottom-margin-10" >';
//                        echo '<img alt="<add client>" class="button-img" src="image/pic1.png"/><br/>';
//                        echo '<span class="button-text">Add Item</span>';
//                        echo '</button>';
//                        break;
//                    
//                    case '6-1':
//                        echo '<button id="btn_6-1"  type="button" class="btn btn-default square-button bottom-margin-10" >';
//                        echo '<img alt="<add client>" class="button-img" src="image/pic1.png"/><br/>';
//                        echo '<span class="button-text">Stock Receiving</span>';
//                        echo '</button>';
//                        break;
//                    
//                    case '6-2':
//                        echo '<button id="btn_6-2"  type="button" class="btn btn-default square-button bottom-margin-10" >';
//                        echo '<img alt="<add client>" class="button-img" src="image/pic1.png"/><br/>';
//                        echo '<span class="button-text">Stock Distribution</span>';
//                        echo '</button>';
//                        break;
//                    
//                    case '6-3':
//                        echo '<button id="btn_6-3"  type="button" class="btn btn-default square-button bottom-margin-10" >';
//                        echo '<img alt="<add client>" class="button-img" src="image/pic1.png"/><br/>';
//                        echo '<span class="button-text">Stock Balance</span>';
//                        echo '</button>';
//                        break;
//                    
//                    case '7-1':
//                        echo '<button id="btn_7-1"  type="button" class="btn btn-default square-button bottom-margin-10" >';
//                        echo '<img alt="<add client>" class="button-img" src="image/pic1.png"/><br/>';
//                        echo '<span class="button-text">Add User</span>';
//                        echo '</button>';
//                        break;
//                    
//                    case '7-2':
//                        echo '<button id="btn_7-2"  type="button" class="btn btn-default square-button bottom-margin-10" >';
//                        echo '<img alt="<add client>" class="button-img" src="image/pic1.png"/><br/>';
//                        echo '<span class="button-text">User Management</span>';
//                        echo '</button>';
//                        break;
//
//                    default:
//                        break;
//                }
                
                $sc = $sc2;
                include 'profile_load_shortcut_menu.php';
                
                $sc = $sc3;
                include 'profile_load_shortcut_menu.php';
                
                $sc = $sc4;
                include 'profile_load_shortcut_menu.php';
                
                $sc = $sc5;
                include 'profile_load_shortcut_menu.php';
                
                ?>
                
                
                <!--  square button 2 -->
<!--                <button id="btn_search_c" type="button" class="btn btn-default square-button bottom-margin-10 <?php echo isset($_SESSION['pvc_mod_client']) && $_SESSION['pvc_mod_client'] > 1 ? '' : 'display-none' ?>">
                    <img alt="" class="button-img" src="image/search_c.png"/><br/>
                    <span class="button-text">Search Client</span>
                </button>-->
<!--                <button id="btn_search_c" type="button" class="btn btn-default square-button bottom-margin-10 <?php echo isset($_SESSION['pvc_mod_client']) && $_SESSION['pvc_mod_client'] > 1 ? '' : 'display-none' ?>">
                    <img alt="" class="button-img" src="image/search_c.png"/><br/>
                    <span class="button-text">Search Client</span>
                </button>
                <button id="btn_search_c" type="button" class="btn btn-default square-button bottom-margin-10 <?php echo isset($_SESSION['pvc_mod_client']) && $_SESSION['pvc_mod_client'] > 1 ? '' : 'display-none' ?>">
                    <img alt="" class="button-img" src="image/search_c.png"/><br/>
                    <span class="button-text">Search Client</span>
                </button>
                <button id="btn_search_c" type="button" class="btn btn-default square-button bottom-margin-10 <?php echo isset($_SESSION['pvc_mod_client']) && $_SESSION['pvc_mod_client'] > 1 ? '' : 'display-none' ?>">
                    <img alt="" class="button-img" src="image/search_c.png"/><br/>
                    <span class="button-text">Search Client</span>
                </button>-->
                
                
            </div>

            <div class="col-sm-11 nopadding">
                <img id="imgLoading" style="display:none; z-index: 10;" class='pvc-loading' src='image/Loading.gif'/>
               
            <!-- place to put the page content -->
                <div id="divContent" class="container-fluid pvc-centreContent pvc-modal-area" style="overflow: auto; background: url(image/bgimg.jpg) no-repeat left 35%; background-size: 100% auto;">
                <?php
                    include 'notice.inc.php';
                ?>
                </div>
            </div>
        </div>        
    </div>

    <!-- page footer -->
    <div id="divfooter" class="container-fluid footerbar">    
        <div class="row">
            <div class="col-sm-6 "><small>Software by HiSP Sri Lanka (Pvt) Ltd.</small></div>
            <div class="col-sm-6 text-right"> <small>All rights reserved (c) 2017</small></div>
        </div>
    </div>
</body>
</html>
